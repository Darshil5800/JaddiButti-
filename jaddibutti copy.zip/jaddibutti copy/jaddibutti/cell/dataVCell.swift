//
//  dataVCell.swift
//  jaddibutti
//
//  Created by darshil bambharoliya on 09/06/24.
//

import UIKit

class dataVCell: UICollectionViewCell {
    
    @IBOutlet weak var imgView: UIImageView!
    
    @IBOutlet weak var titleLbl: UILabel!
    
    
    
    
}
