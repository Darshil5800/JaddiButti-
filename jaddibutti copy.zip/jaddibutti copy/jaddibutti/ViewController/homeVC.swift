//
//  homeVC.swift
//  jaddibutti
//
//  Created by darshil bambharoliya on 08/06/24.
//

import UIKit

class homeVC: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
}
