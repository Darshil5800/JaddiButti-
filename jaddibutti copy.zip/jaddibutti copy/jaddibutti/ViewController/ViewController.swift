//
//  ViewController.swift
//  jaddibutti
//
//  Created by darshil bambharoliya on 07/06/24.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var btnPlay: UIButton!
    
    @IBOutlet weak var btnSetting: UIButton!
    
    @IBOutlet weak var btnInfo: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.btnPlay.layer.cornerRadius = 10
        self.btnInfo.layer.cornerRadius = 10
        self.btnSetting.layer.cornerRadius = 10
        
    }

    @IBAction func clickOnPlay(_ sender: UIButton) {
        
        PushVC(Screen: "dataVC")
        
    }
    
    @IBAction func clickOnSetting(_ sender: UIButton) {
        
        PushVC(Screen: "settingVC")
        
    }

    @IBAction func clickOnInfo(_ sender: UIButton) {
        
        PresentVC(Screen: "infoVC")
        
    }
}




extension ViewController {
    func PushVC(Screen: String) {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(identifier: Screen)
        
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func PresentVC(Screen : String) {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(identifier: Screen)
        self.present(vc, animated: true)
        }
}
