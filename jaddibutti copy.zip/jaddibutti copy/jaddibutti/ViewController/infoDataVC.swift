//
//  infoDataVC.swift
//  jaddibutti
//
//  Created by darshil bambharoliya on 09/06/24.
//

import UIKit

class infoDataVC: UIViewController {

    @IBOutlet weak var titleLbl: UILabel!
    
    @IBOutlet weak var descLbl: UILabel!
    
    
    @IBOutlet weak var doneBtn: UIButton!
    
    var titleLbls = String()
    var descLbls = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.doneBtn.layer.cornerRadius = 10
        
        self.titleLbl.text = self.titleLbls
        self.descLbl.text = self.descLbls
    }
    
    
    @IBAction func clickOnPrev(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
}
