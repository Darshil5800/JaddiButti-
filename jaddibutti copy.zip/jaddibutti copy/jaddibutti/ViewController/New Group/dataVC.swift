//
//  dataVC.swift
//  jaddibutti
//
//  Created by darshil bambharoliya on 09/06/24.
//

import UIKit

class dataVC: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    
    @IBOutlet weak var backBtn: UIButton!
    
    @IBOutlet weak var collcections: UICollectionView!
    
    
    var namesTrees = ["Neem","Tulsi","Amla","Arjuna","Ashwagandha","Moringa","Bael","Haritaki","Sandalwood","Peepal","Jamun"]
    
    var imagesTree = [UIImage(named: "1Neem"),
            UIImage(named: "2Tulsi"),
            UIImage(named: "3Amla"),
            UIImage(named: "4Arjuna"),
            UIImage(named: "5.Ashwagandha"),
            UIImage(named: "6moringa"),
            UIImage(named: "7bael"),
            UIImage(named: "8haritaki"),
            UIImage(named: "9Sandalwood"),
            UIImage(named: "10peepal"),
            UIImage(named: "11Jamun") ]
    
    var desOfTrees = ["Neem Leaves: Enjoy as a revitalizing juice or soothing tea. Fresh leaves can be blended into a paste for direct application on the skin. Neem Oil: Perfect for direct application on skin and hair, or as a potent ingredient in various cosmetic formulations. Neem Powder: Enhance your beauty regimen by adding it to face and hair masks, or take it internally via convenient capsule form. Neem Twigs: Embrace tradition by using neem twigs as natural toothbrushes to support oral hygiene.", "Tulsi Tea: Infuse fresh or dried Tulsi leaves to create a calming tea, perfect for daily consumption to reap its health benefits. Tulsi Oil: Apply Tulsi oil directly to the skin for treating conditions or use it as a soothing massage oil to alleviate pain. Raw Leaves: Boost your health effortlessly by chewing a few fresh Tulsi leaves each day. Daily Routine: Integrate Tulsi into your everyday life to harness its potent therapeutic properties, significantly enhancing your overall health and well-being.", " Amla Juice: Start your day with a refreshing glass of Amla juice to fortify your immune system and enhance overall health. Amla Powder: Integrate Amla powder into your diet by mixing it with water or honey, or adding it to various Ayurvedic preparations for a healthful boost. Amla Oil: Nourish your scalp and hair by applying Amla oil, promoting stronger, healthier hair and preventing hair loss. Amla Supplements: Opt for the convenience of Amla supplements, available in capsule or tablet form, to easily incorporate its benefits into your daily regimen. Chyawanprash: Enjoy the traditional Ayurvedic tonic, Chyawanprash, which harnesses the rejuvenating properties of Amla to invigorate and revitalize the body.", " Arjuna Bark Powder: Typically utilized in its powdered form, this can be mixed with water, milk, or honey and taken daily. Arjuna Tea: By boiling Arjuna bark powder in water, you can prepare a tea that serves as a heart tonic. Arjuna Capsules/Tablets: These are available as supplements, providing a convenient way to consume Arjuna. Topical Application: A paste made from Arjuna bark can be applied directly to wounds and various skin conditions. ", " Root Powder: Typically ingested by blending it into water, milk, or honey for consumption. Capsules/Tablets: Easily accessible as dietary supplements encapsulated or in tablet format. Tinctures and Teas: Employed in diverse concoctions to leverage their health-promoting properties.", " Nutrient-Rich Leaves: Imagine a single leaf of Moringa as nature's treasure trove, bursting with a cornucopia of vital nutrients like a miniature multivitamin. Within its delicate green folds lie a rich reservoir of vitamins (A, C, E, and K), a symphony of minerals (calcium, potassium, iron, and magnesium), and a hearty dose of protein, offering a nourishing feast for the body and soul. Antioxidant Properties: Picture Moringa leaves as nature's shield against the relentless onslaught of oxidative stress. Like valiant guardians, they stand armed with a potent arsenal of antioxidants—flavonoids, polyphenols, and ascorbic acid—ready to repel the assaults of free radicals, safeguarding the body's delicate balance and fortifying its defenses against the ravages of chronic diseases. Anti-Inflammatory Effects: Envision Moringa leaves as soothing balms for the body's fiery flames of inflammation. Embedded within their verdant veils are powerful compounds like isothiocyanates, gently quelling the tumult of inflammatory responses. With each tender touch, they offer respite to weary joints, easing the burden of conditions like arthritis and inflammatory bowel disease, restoring harmony to the body's tumultuous seas. Supports Brain Health: Picture Moringa leaves as gentle guardians of the mind, weaving a protective cloak around delicate neural pathways. Through their intricate dance of neuroprotective effects, they nurture cognitive function and memory, casting a shield against the shadows of neurodegenerative diseases. With each whisper of breeze through their emerald canopy, they offer solace to those navigating the labyrinthine corridors of Alzheimer's and Parkinson's, guiding them towards the light of clarity and remembrance. ", " Diabetes Delicacy: Bael delicately aids in diabetes management, orchestrating blood sugar levels with its hypoglycemic prowess. It conducts a symphony of improved insulin sensitivity and meticulous glucose metabolism control. Bael Beauty Blend: Bael orchestrates a harmonious blend for skin health, its essence a soothing elixir for ailments like eczema, psoriasis, and acne. It choreographs a dance of skin regeneration, offering a graceful relief from the discord of itching and inflammation. Weight Wellness Waltz: Bael gracefully glides into the realm of weight management, a low-calorie marvel twirling with fiber richness. It leads a dance of satiety, elegantly diminishing cravings, and pirouetting towards effective weight management. Liver Symphony: Bael conducts a symphony of support for liver health, orchestrating detoxification with grace. It plays the key notes in eliminating toxins, composing a melody of overall liver well-being.", " Mind Nourishment: Haritaki, hailed as a cerebral elixir in Ayurveda, holds promise in enriching mental faculties, fostering sharper cognition, memory amplification, and fortifying the holistic vitality of the mind. Breath Liberation: With its innate expectorant virtues, Haritaki extends a healing hand to respiratory wellness, liberating from the clutches of coughs, congestion, and respiratory maladies. Epidermal Elixir: Within Ayurvedic alchemy, Haritaki emerges as a cherished ingredient in skincare elixirs, harnessing its antimicrobial prowess to soothe, heal, and rejuvenate the skin canvas, combatting afflictions like acne and eczema. Youthful Resurgence: As a steadfast ally against time's relentless march, regular integration of Haritaki into one's routine may orchestrate a symphony of cellular renewal and revitalization, offering a glimpse into the fountain of youth.", "Cancer-fighting Potential: Sandalwood's unique compounds show promise in combatting cancer, especially skin malignancies. Ongoing investigations delve into its capacity not only to treat but also to prevent cancer, adding to its allure as a potent health ally. Urinary Harmony: Within Ayurvedic practices, sandalwood emerges as a trusted remedy for urinary afflictions, offering a gentle yet effective cleanse for the urinary system. Its holistic approach promotes balance and vitality in urinary tract health. Breath of Relief: A whiff of sandalwood's aromatic essence extends beyond mere fragrance; it becomes a balm for respiratory discomforts like coughs and colds. With its soothing touch, sandalwood oil breathes comfort into the lungs, easing congestion and fostering respiratory wellness.", " Nature's Antibiotic: The Peepal tree's leaves and bark are nature's own antimicrobial agents, effectively combating a myriad of bacterial and fungal infections. Harnessing the power of Peepal leaf extract can facilitate wound healing and act as a shield against infections. Tranquility in a Leaf: Within Ayurveda, the Peepal tree emerges as a symbol of serenity. Imbibe the calming essence of Peepal by sipping on a tea brewed from its leaves, ushering in relief from stress, anxiety, and a serene state of relaxation. Dental Delight: Embrace the age-old wisdom of oral care with Peepal leaves and twigs, revered for their dental prowess. Enriched with properties that fortify teeth and gums, this tradition not only wards off dental woes but also leaves behind a breath of freshness.", " Digestive Delight: Sink your teeth into Jamun fruit, a fiber-rich treat that not only aids digestion but also ensures your gastrointestinal system stays in shipshape, preventing the discomfort of constipation. Immune Powerhouse: Let Jamun be your shield against illness! Packed with a cornucopia of antioxidants, especially the mighty vitamin C, it fortifies your immune system, standing guard against invading infections. Liver's Lifesaver: Give your liver the love it deserves with Jamun. Its hepatoprotective prowess shields this vital organ from harm's way, ensuring it thrives in a sea of health. Oral Oasis: Discover the secret to a fresh, healthy smile with Jamun. Whether chewing its leaves or incorporating its bark into your oral regimen, its antimicrobial magic keeps oral infections at bay and bids adieu to pesky bad breath."]

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.backBtn.layer.cornerRadius = 10
        
        self.collcections.dataSource = self
        self.collcections.delegate = self
        

    }
    
    @IBAction func clickOnPrev(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.namesTrees.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collcections.dequeueReusableCell(withReuseIdentifier: "dataVCell", for: indexPath) as? dataVCell
        
        cell!.titleLbl.text = namesTrees[indexPath.row]
        cell!.imgView.image = imagesTree[indexPath.row]
        
        return cell!
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(identifier: "infoDataVC") as! infoDataVC
        
     
        vc.titleLbls = self.namesTrees[indexPath.row]
        vc.descLbls = self.desOfTrees[indexPath.row]
        self.navigationController?.pushViewController(vc, animated: true)
    }

}
