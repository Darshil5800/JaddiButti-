//
//  infoVC.swift
//  jaddibutti
//
//  Created by darshil bambharoliya on 09/06/24.
//

import UIKit

class infoVC: UIViewController {
    
    @IBOutlet weak var infoApp: UILabel!
    
    @IBOutlet weak var doneBtn: UIButton!
    
    
    var infoAp = "Jaddibutti : Your Guide to the Healing Power of Trees. Extensive Tree Database: Access detailed information on a wide variety of trees, including their Ayurvedic names, botanical names and common names. Health Benefits: Learn about the specific health benefits each tree offers. From boosting immunity to improving digestion, discover how different trees can enhance your well-being. Expert Insights: Read articles and insights from Ayurvedic experts on the historical and cultural significance of trees in Ayurveda. Offline Access: Download information for offline access, ensuring you can reference the app anytime, anywhere."

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.doneBtn.layer.cornerRadius = 10
        
        self.infoApp.text = self.infoAp
    }
    
    @IBAction func clickOnPrev(_ sender: UIButton) {
        
        self.dismiss(animated: true)
    }
    
}
