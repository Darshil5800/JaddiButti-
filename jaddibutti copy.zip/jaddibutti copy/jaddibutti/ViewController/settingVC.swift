//
//  settingVC.swift
//  jaddibutti
//
//  Created by darshil bambharoliya on 10/06/24.
//

import UIKit
import StoreKit

class settingVC: UIViewController{
    
    var AppName = Bundle.main.infoDictionary?[kCFBundleNameKey as String] as? String

    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    
    }
    
    @IBAction func clickOn(_ sender: UIButton) {
        pushVC(scrren: "ViewController")
    }
    
    @IBAction func clickOnShare(_ sender: UIButton) {
        
        
        
        guard let appName = AppName else { return }
        self.share(items: [appName, URL.init(string: /*BaseURL*/) as Any])
        
    }
    
    @IBAction func clickOnRate(_ sender: UIButton) {
        
        self.rateUs()
        
    }
    
    
    
    @IBAction func clickOnInfo(_ sender: UIButton) {
        
        presentVC(screen: "infoVC")
    }
    
    
}

extension settingVC {
    func pushVC(scrren : String) {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(identifier: scrren)
        
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func presentVC(screen : String) {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(identifier: screen)
        
        self.present(vc, animated: true)
    }
    
}


extension settingVC {
    
    func share(items : [Any]) {
        let activityController = UIActivityViewController(activityItems: items, applicationActivities: nil)
        activityController.popoverPresentationController?.sourceView = self.view
        self.present(activityController, animated: true, completion: nil)
    }
    
    
    func rateUs() {
        if let scene = UIApplication.shared.connectedScenes.first(where: { $0.activationState == .foregroundActive }) as? UIWindowScene {
            DispatchQueue.main.async {
                SKStoreReviewController.requestReview(in: scene)
            }
        } else {
            print(" - - - - - - Rating view in not present - - - -")
        }
    }
}
